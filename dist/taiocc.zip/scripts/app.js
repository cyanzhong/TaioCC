function init() {
  const main = require("./ui/main");
  main.render();
}

module.exports = {
  init
}